package com.example.foodmenu;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {
    TextView ShowResult,ConvertResult;
    Button Convert,Checkout;
    DecimalFormat num=new DecimalFormat("00.00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ShowResult=(TextView)findViewById(R.id.result_textview);
        ConvertResult=(TextView)findViewById(R.id.converted_textview);
        Convert=(Button)findViewById(R.id.convert_button);
        Checkout=(Button)findViewById(R.id.checkout_button);

        Bundle extras = getIntent().getExtras();
        final String Value1 = extras.getString("Value");
        ShowResult.setText(Value1+" Taka Only");

        Convert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double a=Double.parseDouble(String.valueOf(Value1));
                double b= (a/(84.70));

                ConvertResult.setText(num.format(b)+ " $");
            }
        });

        Checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTaskToBack(true);
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
            }
        });


    }
}