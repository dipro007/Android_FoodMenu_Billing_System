package com.example.foodmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    CheckBox cburger, bburger, cpizza, spizza, sandwich, chicken, pasta;
    Button palceorder;
    TextView showresult;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cburger = (CheckBox) findViewById(R.id.checkbox_1);
        bburger = (CheckBox) findViewById(R.id.checkbox_2);
        cpizza = (CheckBox) findViewById(R.id.checkbox_3);
        spizza = (CheckBox) findViewById(R.id.checkbox_4);
        sandwich = (CheckBox) findViewById(R.id.checkbox_5);
        chicken = (CheckBox) findViewById(R.id.checkbox_6);
        pasta = (CheckBox) findViewById(R.id.checkbox_7);
        palceorder = (Button) findViewById(R.id.place_order);
        showresult = (TextView) findViewById(R.id.result_textview);

        palceorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double v1 = 0,v2 = 0,v3 = 0,v4 = 0,v5 = 0,v6 = 0,v7 = 0,total;
                if (cburger.isChecked()){
                    v1 = 120;
                }
                if (bburger.isChecked()){
                    v2 = 180;
                }
                if (cpizza.isChecked()){
                    v3 = 250;
                }
                if (spizza.isChecked()){
                    v4 = 350;
                }
                if (sandwich.isChecked()){
                    v5 = 110;
                }
                if (chicken.isChecked()){
                    v6 = 130;
                }
                if (pasta.isChecked()){
                    v7 = 280;
                }
                total = v1 + v2 + v3 + v4 + v5 + v6 + v7;
                String val = String.valueOf(total);

                Intent i = new Intent(MainActivity.this,MainActivity2.class);
                i.putExtra("Value", val);

                startActivity(i);

            }
        });


    }
}